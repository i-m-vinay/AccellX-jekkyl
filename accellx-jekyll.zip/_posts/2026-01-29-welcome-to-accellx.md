---
layout: page
title: Welcome to AccellX Blog
---

This is your first blog post.

You can now:
- Add markdown posts
- Use layouts
- Manage content cleanly